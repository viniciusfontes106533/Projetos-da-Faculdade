package br.com.fecaf.model;

import java.util.Scanner;



public class Triangulo {

    public double base, lado2, lado3, area, perimetro, altura;

    Scanner scanner = new Scanner(System.in);

    public boolean cadastrarTriangulo() {
        System.out.println("_____________________________________");
        System.out.println("/*   Cadastro Triângulo */");
        System.out.println("_____________________________________");
        System.out.print(" Informe a Base:     ");
        base = scanner.nextDouble();
        System.out.print(" Informe o lado 2:     ");
        lado2 = scanner.nextDouble();
        System.out.print("Informe o lado 3:   ");
        lado3 = scanner.nextDouble();
        System.out.print("Informe a Altura: ");
        altura = scanner.nextDouble();
        System.out.println("/* Triângulo Cadastrado com Sucesso !");
        System.out.println("_____________________________________");

        return true;
    }

    public void calcularArea() {
        System.out.println("_____________________________________");
        System.out.println("/*        Calculando Area        */");
        System.out.println("_____________________________________");

        area = (base * altura) / 2;
        System.out.println("A área é: " + area);
        System.out.println("_____________________________________");
    }

    public void calcularPerimetro() {
        System.out.println("_____________________________________");
        System.out.println("/*      Calculando Perimetro     */");
        System.out.println("_____________________________________");

        perimetro = base + lado2 + lado3;
        System.out.println("O perimetro é: " + perimetro);
        System.out.println("_____________________________________");
    }

    public void definirTipo () {
        System.out.println("_____________________________________");
        System.out.println("/*        Definindo Tipo         */");
        System.out.println("_____________________________________");

        if (base == lado2 && base == lado3) {
            System.out.println("Este Triângulo é Equilátero ...");
        }
        else if (base != lado2 && base != lado3 && lado2 != lado3) {
            System.out.println("Este Triângulo é Escaleno ...");
        }
        else {
            System.out.println("Este Triângulo é Isosceles ...");
        }

    }

    // Conferindo Catetos e Hipotenusas
    public void definirCH () {
        double h, cma, cme; //hipotenusa, cateto maior e menor
        //pra caso a base seja a hipotenusa
        if (base > lado2 && base > lado3) {
            h = base;
            cma = Math.max(lado2, lado3);// pra guardar o maior valor
            cme = Math.min(lado2, lado3);// pra guarda o menor
        }
        //pra caso o lado2 seja a hipotenusa
        else if (lado2 > base && lado2 > lado3) {
            h = lado2;
            cma = Math.max(base, lado3);
            cme = Math.min(base, lado3);
        }
        else {
            //pra caso o lado 3 seja a hipotenusa
            h = lado3;
            cma = Math.max(base, lado2);
            cme = Math.min(base, lado2);
        }
        //só pra exibir os valores correspondentes a cada cateto e hipotenusa
        System.out.println("A hipotenusa é: " + h);
        System.out.println("O cateto maior é: " + cma);
        System.out.println("O cateto menor é: " + cme);

        // pra validar se é um 3 4 5
        boolean triangulo345 = (cme*cme)+(cma*cma) == (h*h);
        if (triangulo345 == true && cma %4 == 0 && cme %3 == 0) {
            System.out.println("É um triângulo 3, 4 e 5 !!!");
        } else {
            System.out.println("É um triângulo retângulo fora do padrão 3 4 5 !!!");
        }


    }








}


